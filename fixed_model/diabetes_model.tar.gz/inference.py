import joblib
import json
import os

def model_fn(model_dir):
    """Load the model"""
    model_path = os.path.join(model_dir, "diabetes_model.pkl")
    model = joblib.load(model_path)
    return model

def input_fn(request_body, request_content_type):
    """Deserialize JSON input"""
    if request_content_type == "application/json":
        return json.loads(request_body)
    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")

def predict_fn(input_data, model):
    """Make predictions"""
    prediction = model.predict([input_data])
    return prediction.tolist()

def output_fn(prediction, accept):
    """Serialize output"""
    if accept == "application/json":
        return json.dumps(prediction), accept
    else:
        raise ValueError(f"Unsupported accept type: {accept}")
